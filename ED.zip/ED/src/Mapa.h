#ifndef _Mapa_h_
#define _Mapa_h_

#include "Utils.h"

void criarMapa (int***, int);
void populaMapa(int**,  int);
void printMapa (int**,  int);
void limparMapa(int**,  int);

#endif