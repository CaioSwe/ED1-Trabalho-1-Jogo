#ifndef _Delimiters_h_
#define _Delimiters_h_

#define SCREEN_WIDTH 600
#define SCREEN_HEIGHT 600

#define MAX_STRSIZE 100
#define MAX_FRAMES 100

#define TAM 20

static bool LOG = false;

#endif